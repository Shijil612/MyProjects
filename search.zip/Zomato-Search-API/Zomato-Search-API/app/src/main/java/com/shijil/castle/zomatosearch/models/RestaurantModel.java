package com.vijay.castle.zomatosearch.models;

/**
 * Created by vijay on 6/9/17.
 */

public class RestaurantModel {

    private RestaurantInfoModel restaurant;

    public RestaurantInfoModel getRestaurant() {
        return restaurant;
    }
}
