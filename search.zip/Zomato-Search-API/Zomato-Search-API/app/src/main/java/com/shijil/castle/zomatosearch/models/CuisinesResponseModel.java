package com.vijay.castle.zomatosearch.models;

import java.util.List;

/**
 * Created by vijay on 6/9/17.
 */

public class CuisinesResponseModel {
    private List<CuisinesModel> cuisines;

    public List<CuisinesModel> getCuisines() {
        return cuisines;
    }
}
